/**************************************************************************************************/
/* Title        :  EGMM_POC                                                                       */
/*------------------------------------------------------------------------------------------------*/
/* File         :  GMD.c                                                                          */
/* Author       :  Justin Reina                                                                   */
/* Company      :  Intellectual Ventures Laboratory                                               */
/* Project      :  MAISE EGMM Proof of Concept Device (De-risk testing)                           */
/* Created      :  26 Mar 2018                                                                    */
/* Compiler     :  Microchip MPLAB XC16, Ver. 1.33                                                */
/* Target       :  PIC24FJ256GA702-I/ML                                                           */
/*------------------------------------------------------------------------------------------------*/
/* Description  :  x                                                                              */
/* Todos        : select grain type                                                               */
/*------------------------------------------------------------------------------------------------*/
/* Copyright    :  (c) 2018 Intellectual Ventures  All rights reserved                            */
/**************************************************************************************************/

//Project
#include "Globals.h"

//Test Values (@src  doc/ref/chung-pfost/calcs/GMD-Calcs.xlsx)
const float t1[22]   = {-30, -20, 0, 20, 40, 60, 75, 80, 100, 120, 120, 160, 180, 200, 220, 240, 260, 280, 300, 320, 340, 360}; //[�C]
const float rh1[22]  = {0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5};
const float gmd1[22] = {0.453785697, 0.344135313, 0.211735389, 0.174068838, 0.151268006, 0.134866043, 0.125000437, 0.122047452, 0.111523835, 0.102596885, 0.102596885, 0.087995333, 0.081858876, 0.076301225, 0.07122254, 0.066546776, 0.062214674, 0.058179157, 0.054402203, 0.050852666, 0.047504708, 0.044336658};

const float t2[21] = {50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50}; //[�C]
const float rh2[21] = {0.01, 0.05, 0.1, 0.15, 0.2, 0.25, 0.3, 0.35, 0.4, 0.45, 0.5, 0.55, 0.6, 0.65, 0.7, 0.75, 0.8, 0.85, 0.9, 0.95, 0.99};
const float gmd2[21] = {-0.009896811, 0.015459754, 0.030978079, 0.042400303, 0.052098034, 0.06089935, 0.069214562, 0.077293807, 0.085316222, 0.093429851, 0.101774239, 0.11049733, 0.119772713, 0.129822616, 0.14095494, 0.153631655, 0.168612433, 0.18730715, 0.212865133, 0.255313386, 0.351431772};

//Vars
float expected  = -1;
float calc = -1;


/*------------------------------------------------------------------------------------------------*/
/* Function     : gmd                                                         					  */
/*                                                                            					  */
/* Description  : pf gmd calc                                                 					  */
/*                                                                            					  */
/* Equation     : GMD = E - F*ln[-(T+C)*ln(RH)]                               					  */
/*                                                                            					  */
/* Arguments    : none                                                        					  */
/*                                                                            					  */
/* Returns      : never returns                                               					  */
/*                                                                            					  */
/*------------------------------------------------------------------------------------------------*/

float gmd( float t, float rh )
{
	volatile float m = log(rh);

	m = -(t+CP_C)*m;

	m = log(m);

	m = CP_E - CP_F*m;

	return m;
}


/*------------------------------------------------------------------------------------------------*/
/* Function     : test_gmdCalcs                                               					  */
/*                                                                            					  */
/* Description  : validate gmd() routine calculations                         					  */
/*                                                                            					  */
/* Arguments    : none                                                        					  */
/*                                                                            					  */
/* Returns      : none                                                        					  */
/*                                                                            					  */
/*------------------------------------------------------------------------------------------------*/

bool test_gmdCalcs( void ) 
{
	int i;

	float maxErr = -1;
	int maxInd, maxSet;

	int n1 = sizeof(gmd1)/sizeof(float);
	int n2 = sizeof(gmd2)/sizeof(float);

	for(i=0; i<n2; i++) {
		float t  = t2[i];
		float rh = rh2[i];
		expected = gmd2[i];

		calc = gmd(t, rh);

		//Calc err
		float diff = calc - expected;
		diff = fabsf(diff);
		if(diff > maxErr) {
			maxErr = diff;
			maxInd = i;
			maxSet = 1;
		}

		if(diff > 0.1) {
		return false;
		}
	}

	for(i=0; i<n1; i++) {
		float t  = t1[i];
		float rh = rh1[i];
		expected = gmd1[i];

		calc = gmd(t, rh);

		//Calc err
		float diff = calc - expected;
		diff = fabsf(diff);
		if(diff > maxErr) {
			maxErr = diff;
			maxInd = i;
			maxSet = 2;
		}

		if(diff > 0.1) {
			return false;
		}
	}

	return true;
}

/**************************************************************************************************/
