/**************************************************************************************************/
/* Title        :  EGMM Data Acquisition from HDC2010                                             */
/*------------------------------------------------------------------------------------------------*/
/* File         :  DataAcq.c                                                                      */
/* Author       :  Daniel Morris                                                                  */
/* Company      :  Intellectual Ventures Laboratory                                               */
/* Project      :  MAISE EGMM Proof of Concept Device (De-risk testing)                           */
/* Created      :  12 Sep 2018                                                                    */
/* Compiler     :  Microchip MPLAB XC16, Ver. 1.33                                                */
/* Target       :  PIC24FJ256GA702-I/ML                                                           */
/*------------------------------------------------------------------------------------------------*/
/* Description  :  Data Acquisition from HDC2010 digital sensor                                   */
/*------------------------------------------------------------------------------------------------*/
/* Copyright    :  (c) 2018 Intellectual Ventures  All rights reserved                            */
/**************************************************************************************************/

#define DATAACQ_C

/**************************************************************************************************/
/*                                         INCLUDES                                               */
/**************************************************************************************************/

//Project
#include "Globals.h"

/**************************************************************************************************/
/*                                          DEFINES                                               */
/**************************************************************************************************/

#define HDC2010ADDR  (0x80)   							// HDC2010 I2C address (0x40<<1)
#define HDC1080ADDR  (0x80)   							// HDC1080 I2C address (0x40<<1)
#define I2CWRITE     (0x00)   							// WRITE bit (clear)
#define I2CREAD      (0x01)   							// READ bit (set)

/**************************************************************************************************/
/*                                      FUNCTION DEFINITIONS                                      */
/**************************************************************************************************/


/*------------------------------------------------------------------------------------------------*/
/* Function     :  ConfigureI2C                                               					  */
/*                                                                            					  */
/* Description  :  Configure I2C to access HDC2010 temp/humidity sensor       					  */
/*                                                                            					  */
/* Arguments    :  None                                                       					  */
/*                                                                            					  */
/* Returns      :  None                                                       					  */
/*                                                                            					  */
/*------------------------------------------------------------------------------------------------*/

void ConfigureI2C( void )
{
	IEC3bits.MI2C2IE = 0;      // Disable I2C interrupt

	I2C2CONL = 0x2800;
	// I2CEN    = 0   I2C off, for now
	// I2SIDL   = 1   I2C stops in idle
	// SCLREL   = 0   not used (slave mode only)
	// STRICT   = 1   device allowed to generate reserved addresses
	// A10M     = 0   I2CxADD is a 7 bit slave address
	// DISSLW   = 0   Slew rate control is enabled for 400KHz high speed mode
	// SMEN     = 0   Disable SMBus-specific input levels
	// GCEN     = 0   General call address disabled (ignored, slave mode only)
	// STREN    = 0   Disables clock stretching
	// ACKDT    = 0   ACK sent
	// ACKEN    = 0   Acknowledge sequence idle
	// RCEN     = 0   Receive not in progress
	// PEN      = 0   Stop condition is idle
	// RSEN     = 0   Restart condition is idle
	// SEN      = 0   Start condition is idle

	I2C2CONH = 0x0000;
	// PCIE     = 0   Stop detection interrupt disabled
	// SCIE     = 0   Start detection interrupt disabled
	// BOEN     = 0   I2CxRCV is only updated if I2COV is clear
	// SDAHT    = 0   Minimum of 100ns hold time on SDAx after SCL fall
	// SBCDE    = 0   Ignored, slave mode only
	// AHEN     = 0   Ignored, slave mode only
	// DHEN     = 0   Data holding disabled

	I2C2BRG = 18;     		  // I2C-Baud = FCY/(2*(BRG+2)) - e.g. [18]: "16MHz -> 400kHz"

	I2C2CONLbits.I2CEN = 1;    // Enable I2C module

	return;
} /* ConfigureI2C */


/*------------------------------------------------------------------------------------------------*/
/* Function     :  WriteRegister                                              					  */
/*                                                                            					  */
/* Description  :  Write a value to register on HDC1080 via I2C               					  */
/*                                                                            					  */
/* Arguments    :  None                                                       					  */
/*                                                                            					  */
/* Returns      :  None                                                       					  */
/*                                                                            					  */
/*------------------------------------------------------------------------------------------------*/

int WriteRegister( uint8_t RegAddr, uint16_t Data )
{
	I2C2CONLbits.SEN = 1;               // Send I2C START
	while ( I2C2CONLbits.SEN );         // Wait for START to complete

	I2C2TRN = (HDC1080ADDR | I2CWRITE); // Send slave address and write bit
	while ( I2C2STATbits.TRSTAT );      // Wait for transmit complete

	if ( I2C2STATbits.ACKSTAT )         // NACK, halt transmission
		return -1;

	I2C2TRN = RegAddr;                  // Send register address
	while ( I2C2STATbits.TRSTAT );      // Wait for transmit complete

	if ( I2C2STATbits.ACKSTAT )         // NACK, halt transmission
		return -1;

	I2C2TRN = (uint8_t)((Data >> 8) & 0x00FF);   // Send data MSB
	while ( I2C2STATbits.TRSTAT );      // Wait for transmit complete

	if ( I2C2STATbits.ACKSTAT )         // NACK, halt transmission
		return -1;

	I2C2TRN = (uint8_t)(Data & 0x00FF); // Send data LSB
	while ( I2C2STATbits.TRSTAT );      // Wait for transmit complete

	if ( I2C2STATbits.ACKSTAT )         // NACK, halt transmission
		return -1;

	I2C2CONLbits.PEN = 1;               // Send I2C STOP
	while ( I2C2CONLbits.SEN );         // Wait for STOP to complete

	return EXIT_SUCCESS;
} /* WriteRegister */


/*------------------------------------------------------------------------------------------------*/
/* Function     :  ReadRHT                                                    					  */
/*                                                                            					  */
/* Description  :  Read measurements from HDC1080                             					  */
/*                                                                            					  */
/* Arguments    :  None                                                       					  */
/*                                                                            					  */
/* Returns      :  None                                                       					  */
/*                                                                            					  */
/*------------------------------------------------------------------------------------------------*/

int ReadRHT( uint16_t *Temp, uint16_t *RHum )
{
	uint16_t HDC1080_TempRaw;
	uint16_t HDC1080_RHumRaw;
	uint32_t Val;

	I2C2CONLbits.SEN = 1;               // Send I2C START
	while ( I2C2CONLbits.SEN );         // Wait for START to complete

	I2C2TRN = (HDC1080ADDR | I2CWRITE); // Send slave address and write bit
	while ( I2C2STATbits.TRSTAT );      // Wait for transmit complete

	if ( I2C2STATbits.ACKSTAT )         // NACK, halt transmission
		return -1;

	I2C2TRN = 0x00;                     // Send register address  (Temp LSB)
	while ( I2C2STATbits.TRSTAT );      // Wait for transmit complete

	if ( I2C2STATbits.ACKSTAT )         // NACK, halt transmission
		return -1;

	//Wait for measurement time (14b = 6.5ms)
	uint32_t i = TICK_CT_DAQ;
	while(i--);

	I2C2CONLbits.SEN = 1;               // Send new I2C START
	while ( I2C2CONLbits.SEN );         // Wait for START to complete

	I2C2TRN = (HDC1080ADDR | I2CREAD); // Send slave address and read bit
	while ( I2C2STATbits.TRSTAT );      // Wait for transmit complete

	if ( I2C2STATbits.ACKSTAT )         // NACK, halt transmission
		return -1;

	I2C2CONLbits.RCEN = 1;              // Start a byte read (clocks)
	while ( I2C2CONLbits.RCEN );        // Wait for reception
	HDC1080_TempRaw = (uint16_t)I2C2RCV;  // Get MSB
	HDC1080_TempRaw <<= 8;              // Shift into place
	I2C2CONLbits.ACKDT = 0;             // ACK reception
	I2C2CONLbits.ACKEN = 1;             // Send ACK
	while ( I2C2CONLbits.ACKEN );       // Wait for complete

	I2C2CONLbits.RCEN = 1;              // Start a byte read (clocks)
	while ( I2C2CONLbits.RCEN );        // Wait for reception
	HDC1080_TempRaw |= (uint16_t)I2C2RCV; // Get LSB
	I2C2CONLbits.ACKDT = 0;             // ACK reception
	I2C2CONLbits.ACKEN = 1;             // Send ACK
	while ( I2C2CONLbits.ACKEN );       // Wait for complete

	I2C2CONLbits.RCEN = 1;              // Start a byte read (clocks)
	while ( I2C2CONLbits.RCEN );        // Wait for reception
	HDC1080_RHumRaw = (uint16_t)I2C2RCV;  // Get MSB
	HDC1080_RHumRaw <<= 8;              // Shift into place
	I2C2CONLbits.ACKDT = 0;             // ACK reception
	I2C2CONLbits.ACKEN = 1;             // Send ACK
	while ( I2C2CONLbits.ACKEN );       // Wait for complete

	I2C2CONLbits.RCEN = 1;              // Start a byte read (clocks)
	while ( I2C2CONLbits.RCEN );        // Wait for reception
	HDC1080_RHumRaw |= (uint16_t)I2C2RCV; // Get LSB
	I2C2CONLbits.ACKDT = 1;             // NACK reception (done)
	I2C2CONLbits.ACKEN = 1;             // Send NACK
	while ( I2C2CONLbits.ACKEN );       // Wait for complete

	I2C2CONLbits.PEN = 1;               // Send I2C STOP

	// While waiting for stop to complete, do calculations
	Val = (uint32_t)HDC1080_TempRaw * 33000L; // x165  (x100 for decimal, x2 for rounding)
	Val >>= 16;
	Val -= 7999L;                             // -40C (x2+1 for rounding)
	Val >>= 1;                                // Round
	*Temp = (uint16_t)Val;

	Val = (uint32_t)HDC1080_RHumRaw * 20000L; // x100 (x100 for decimal, x 2 for rounding)
	Val >>= 16;
	Val += 1L;                                // +1 for rounding
	Val >>= 1;                                // Round
	*RHum = (uint16_t)Val;

	while ( I2C2CONLbits.SEN );         // Wait for STOP to complete

	return EXIT_SUCCESS;
} /* ReadRHT */



/*------------------------------------------------------------------------------------------------*/
/* Function     :  DAQ_Wait                                                    					  */
/*                                                                            					  */
/* Description  :  x	                             					  						  */
/*                                                                            					  */
/* Arguments    :  None                                                       					  */
/*                                                                            					  */
/* Returns      :  None                                                       					  */
/*                                                                            					  */
/*------------------------------------------------------------------------------------------------*/

void DAQ_Wait( void )
{
	DaqTime = 2;

	while ( DaqTime );

	return;
}

/**************************************************************************************************/

