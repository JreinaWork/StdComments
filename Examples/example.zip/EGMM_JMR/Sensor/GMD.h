/**************************************************************************************************/
/* Title        :  EGMM_POC                                                                       */
/*------------------------------------------------------------------------------------------------*/
/* File         :  GMD.h                                                                          */
/* Author       :  Justin Reina                                                                   */
/* Company      :  Intellectual Ventures Laboratory                                               */
/* Project      :  MAISE EGMM Proof of Concept Device (De-risk testing)                           */
/* Created      :  26 Mar 2018                                                                    */
/* Compiler     :  Microchip MPLAB XC16, Ver. 1.33                                                */
/* Target       :  PIC24FJ256GA702-I/ML                                                           */
/*------------------------------------------------------------------------------------------------*/
/* Description  :  x                                                                              */
/*------------------------------------------------------------------------------------------------*/
/* Copyright    :  (c) 2018 Intellectual Ventures  All rights reserved                            */
/**************************************************************************************************/
#ifndef GMD_H_
#define GMD_H_

//Project
#include "Globals.h"

//Definitions (Corn, yellow dent)
#define CP_A        ((float)312.30)
#define CP_B        ((float)16.958)
#define CP_C        ((float)30.205)
#define CP_E        ((float)0.33872)
#define CP_F        ((float)0.058970)

//Globals
extern float gmd( float t, float rh );
extern bool test_gmdCalcs( void );

#endif  /* GMD_H_ */

