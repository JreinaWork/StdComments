/**************************************************************************************************/
/* Title        :  EGMM_POC Main                                                                  */
/*------------------------------------------------------------------------------------------------*/
/* File         :  Main.c                                                                         */
/* Author       :  Daniel Morris                                                                  */
/* Company      :  Intellectual Ventures Laboratory                                               */
/* Project      :  MAISE EGMM Proof of Concept Device (De-risk testing)                           */
/* Created      :  12 Sep 2018                                                                    */
/* Compiler     :  Microchip MPLAB XC16, Ver. 1.33                                                */
/* Target       :  PIC24FJ256GA702-I/ML                                                           */
/*------------------------------------------------------------------------------------------------*/
/* Description  :  Startup and main loop                                                          */
/*------------------------------------------------------------------------------------------------*/
/* Copyright    :  (c) 2018 Intellectual Ventures  All rights reserved                            */
/**************************************************************************************************/

#define MAIN_C

/**************************************************************************************************/
/*                                            INCLUDES                                            */
/**************************************************************************************************/

//Project
#include "Globals.h"

/**************************************************************************************************/
/*                                       GLOBAL VARIABLES                                         */
/**************************************************************************************************/
	uint16_t RH;
	uint16_t Temp;

	char TimeStr[10];
	char RHStr[10];
	char TempStr[10];

/**************************************************************************************************/
/*                                    FUNCTION DECLARATIONS                                       */
/**************************************************************************************************/

void KEYS_Read( void );
void BLE_Print( uint16_t Temp, uint16_t RH, char *TimeStr );
void LAUNCH_Setup( void );

/**************************************************************************************************/
/*                                      FUNCTION DEFINITIONS                                      */
/**************************************************************************************************/


/*------------------------------------------------------------------------------------------------*/
/* Function     :  main                                                       					  */
/*                                                                            					  */
/* Description  :  Main program loop                                          					  */
/*                                                                            					  */
/* Arguments    :  None                                                       					  */
/*                                                                            					  */
/* Returns      :  never returns                                              					  */
/*                                                                            					  */
/*------------------------------------------------------------------------------------------------*/

int main( void )
{
	//Init
	SYSTEM_Initialize();
	LAUNCH_Setup();


	while (1)
	{

		if ( PowerOffNow )
		{
			SYSTEM_PowerDown();
		}

		if ( Key1Pressed )
		{
			KEY1_Reset();
		}

		if ( Key2Pressed )
		{
			if ( !Running )
			{
				RUN_Start();
			}
			else
			{
				Running = false;
			}
			Key2Pressed = false;
		}

		if ( SecondFlag )
		{
			if ( Running )
			{
				// Get some stuff done while waiting for measurement to complete
				sprintf( TimeStr, "%02d:%02d", ElapsedTime/60, ElapsedTime%60 );
				ClearDisplayBuf();

				// Now, wait for data ready
				DAQ_Wait();

				//Read & Display
				ReadRHT( &Temp, &RH );
				DISP_Print();
				BLE_Print(Temp, RH, TimeStr);
			}
			SecondFlag  = false;
		}
	}
}


/*------------------------------------------------------------------------------------------------*/
/* Function     : KEYS_Read	                                                					  */
/*                                                                            					  */
/* Description  : methodology to filter button responses for electrical noise                     */
/*                                                                            					  */
/* Arguments    : none                                                        					  */
/*                                                                            					  */
/* Returns      : none                                                        					  */
/*                                                                            					  */
/*------------------------------------------------------------------------------------------------*/

void KEYS_Read( void )
{
	static uint16_t Key1Count = 0;
	static uint16_t Key2Count = 0;

	if ( Key1Read() )
	{
		Key1Count++;
		if ( Key1Count > CT_POWERDOWN )
		PowerOffNow = true;
		else if ( Key1Count == COUNT_Value(T_RESET_S) )
		Key1Pressed = true;
	}
	else
	{
		Key1Count = 0;
	}

	if ( Key2Read() )
	{
		Key2Count++;
		if ( Key2Count == COUNT_Value(T_KEY2_S) )  					// 30ms
			Key2Pressed = true;
	}
	else
	{
		Key2Count = 0;
	}

	return;
} /* DebounceKeys */


/*------------------------------------------------------------------------------------------------*/
/* Function     :  _T1Interrupt                                               					  */
/*                                                                            					  */
/* Description  :  Interrupt Service Routine for Timer 1                      					  */
/*                 Data acquisition done here                                 					  */
/*                                                                            					  */
/* Arguments    :  None                                                       					  */
/*                                                                            					  */
/* Returns      :  None                                                       					  */
/*                                                                            					  */
/*------------------------------------------------------------------------------------------------*/

void _PSV_ _T1Interrupt( void )
{
	if ( DaqTime )
		DaqTime--;

	if ( Ticks )
	{
		Ticks--;
	}
	else
	{
		Ticks = tickCt(TS_MS);
		SecondFlag = true;
		if ( Running )
			ElapsedTime++;
	}

	if ( (Ticks & 0x01) && (!PowerOffNow) )
		DisplayRefresh();

	KEYS_Read();

	IFS0bits.T1IF = 0;      // Reset Timer 1 interrupt flag and Return from ISR

	return;
}  /* _T1Interrupt */


/*------------------------------------------------------------------------------------------------*/
/* Function     :  LAUNCH_Setup                                               					  */
/*                                                                            					  */
/* Description  :  prep device for launch after boot                           					  */
/*                                                                            					  */
/* Arguments    :  none                                                       					  */
/*                                                                            					  */
/* Returns      :  none                                                       					  */
/*                                                                            					  */
/*------------------------------------------------------------------------------------------------*/

void LAUNCH_Setup( void )
{
	// Wait for display boot completion
	while ( UpdateDisplay );

	// Wait for user indication to proceed
	while ( !Key1Read() );

	//Prep for runtime
	CLOCKS_Init();
	KEYS_Init();

	return;
}


/*------------------------------------------------------------------------------------------------*/
/* Function     :  BLE_Print                                                   					  */
/*                                                                            					  */
/* Description  :  print the BLE message to BM71                              					  */
/*                                                                            					  */
/* Arguments    :  none                                                       					  */
/*                                                                            					  */
/* Returns      :  none                                                       					  */
/*                                                                            					  */
/*------------------------------------------------------------------------------------------------*/

void BLE_Print( uint16_t Temp, uint16_t RH, char *TimeStr )
{
	volatile uint32_t i, j;

	//Clock High
	OSCILLATOR_SetValue(CLOCK_16_MHZ);

	printf( "%d,%s,%02d.%02d,%02d.%02d", (ElapsedTime%100), TimeStr,
	Temp/100, Temp%100, RH/100, RH%100 );

	//wait for completion
	for(i=0; i<DELAY_CT_5_MS; i++) { j--; }

	//Clock Low
	OSCILLATOR_SetValue(CLOCK_2_MHZ);

	return;
} /* printBLE */




/**************************************************************************************************/
