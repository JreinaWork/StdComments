/**************************************************************************************************/
/* Title        :  EGMM Proof of Concept Font Data                                                */
/*------------------------------------------------------------------------------------------------*/
/* File         :  Fonts.h                                                                        */
/* Author       :  Daniel Morris                                                                  */
/* Company      :  Intellectual Ventures Laboratory                                               */
/* Project      :  MAISE EGMM Proof of Concept Device (De-risk testing)                           */
/* Created      :  12 Sep 2018                                                                    */
/* Last update  :  12 Sep 2018                                                                    */
/* Compiler     :  Microchip MPLAB XC16, Ver. 1.33                                                */
/* Target       :  PIC24FJ256GA702-I/ML                                                           */
/*------------------------------------------------------------------------------------------------*/
/* Description  :  Data Acquisition from HDC2010 and resistive sensors                              */
/*------------------------------------------------------------------------------------------------*/
/* Copyright    :  (c) 2018 Intellectual Ventures  All rights reserved                            */
/**************************************************************************************************/

#ifndef FONTS_H
#define	FONTS_H

/**************************************************************************************************/
/*                                           INCLUDES                                             */
/**************************************************************************************************/

//Project
#include "Globals.h"

/**************************************************************************************************/
/*                                          TYPEDEFS                                              */
/**************************************************************************************************/

// This structure describes a single character's display information
typedef struct font_char_info
{
	const uint8_t widthBits;            // width, in bits (or pixels), of the character
	const uint16_t  offset;             // offset of the character's bitmap, in bytes, into the the FONT_INFO's data array
} FONT_CHAR_INFO;	


// Describes a single font
typedef struct font_info
{
	const uint8_t    height;            // height, in bits, of the font's characters
	const uint8_t    startChar;         // the first character in the font (e.g. in charInfo and data)
	const uint8_t    endChar;           // the last character in the font
	const uint8_t    gapPixels;         // number of pixels between characters
	const FONT_CHAR_INFO*   charInfo;   // pointer to array of char information
	const uint8_t*   data;              // pointer to generated array of character visual representation
} FONT_INFO;	


/**************************************************************************************************/
/*                                      GLOBAL CONSTANTS                                          */
/**************************************************************************************************/

/* Font data for Monospac821 BT 16pt */
extern const uint8_t Mono16_Bitmaps[];
extern const FONT_INFO Mono16_FontInfo;
extern const FONT_CHAR_INFO Mono16_Descriptors[];


/* Font data for Monospac821 BT 24pt */
extern const uint8_t MonoBold24_Bitmaps[];
extern const FONT_INFO MonoBold24_FontInfo;
extern const FONT_CHAR_INFO MonoBold24_Descriptors[];

/**************************************************************************************************/

#endif	/* FONTS_H */

