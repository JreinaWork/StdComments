/**************************************************************************************************/
/* Title        :  EGMM Display                                                                   */
/*------------------------------------------------------------------------------------------------*/
/* File         :  Display.c                                                                      */
/* Author       :  Daniel Morris                                                                  */
/* Company      :  Intellectual Ventures Laboratory                                               */
/* Project      :  MAISE EGMM Proof of Concept Device (De-risk testing)                           */
/* Created      :  12 Sep 2018                                                                    */
/* Last update  :  12 Sep 2018                                                                    */
/* Compiler     :  Microchip MPLAB XC16, Ver. 1.33                                                */
/* Target       :  PIC24FJ256GA702-I/ML                                                           */
/*------------------------------------------------------------------------------------------------*/
/* Description  :  Routines to start up and run LCD display via SPI                               */
/*------------------------------------------------------------------------------------------------*/
/* Copyright    :  (c) 2018 Intellectual Ventures  All rights reserved                            */
/**************************************************************************************************/

#define DISPLAY_C

/**************************************************************************************************/
/*                                         INCLUDES                                               */
/**************************************************************************************************/

//Project
#include "Globals.h"

/**************************************************************************************************/
/*                                          DEFINES                                               */
/**************************************************************************************************/

#define BUF0       (0x01)
#define BUF1       (0x02)
#define BUFBOTH    (BUF0|BUF1)

#define BUF0PTR    (&DisplayBuf[0][0][0])
#define BUF1PTR    (&DisplayBuf[1][0][0])

#define DISP_CLEAR (0x20)   							// Command to clear display
#define DISP_WRITE (0x80)   							// Command to write display memory
#define DISP_HOLD  (0x00)   							// Command to hold display

/**************************************************************************************************/
/*                                          TYPEDEFS                                              */
/**************************************************************************************************/

typedef enum displayState {
	DISPLAY_REFRESH,
	DISPLAY_UPDATE
} DisplayState_t;

/**************************************************************************************************/
/*                                      GLOBAL VARIABLES                                          */
/**************************************************************************************************/

uint8_t  DisplayBuf[2][DISP_YSIZE][DISP_XBYTES];
uint16_t DisplayWorkBuf = 0;
bool   DisplayRunning = false;
volatile bool UpdateDisplay  = false;
volatile bool DisplayWriting = false;
volatile uint16_t DisplayLine    = 0;
volatile uint16_t DisplayByte    = 0;
volatile const uint8_t *DisplayAddr;
volatile uint8_t  *DisplayData;
   
const uint8_t GateLine[DISP_YSIZE] = {
	0x80, 0x40, 0xC0, 0x20, 0xA0, 0x60, 0xE0, 0x10,
	0x90, 0x50, 0xD0, 0x30, 0xB0, 0x70, 0xF0, 0x08,
	0x88, 0x48, 0xC8, 0x28, 0xA8, 0x68, 0xE8, 0x18,
	0x98, 0x58, 0xD8, 0x38, 0xB8, 0x78, 0xF8, 0x04,
	0x84, 0x44, 0xC4, 0x24, 0xA4, 0x64, 0xE4, 0x14,
	0x94, 0x54, 0xD4, 0x34, 0xB4, 0x74, 0xF4, 0x0C,
	0x8C, 0x4C, 0xCC, 0x2C, 0xAC, 0x6C, 0xEC, 0x1C,
	0x9C, 0x5C, 0xDC, 0x3C, 0xBC, 0x7C, 0xFC, 0x02,
	0x82, 0x42, 0xC2, 0x22, 0xA2, 0x62, 0xE2, 0x12,
	0x92, 0x52, 0xD2, 0x32, 0xB2, 0x72, 0xF2, 0x0A,
	0x8A, 0x4A, 0xCA, 0x2A, 0xAA, 0x6A, 0xEA, 0x1A,
	0x9A, 0x5A, 0xDA, 0x3A, 0xBA, 0x7A, 0xFA, 0x06,
	0x86, 0x46, 0xC6, 0x26, 0xA6, 0x66, 0xE6, 0x16,
	0x96, 0x56, 0xD6, 0x36, 0xB6, 0x76, 0xF6, 0x0E,
	0x8E, 0x4E, 0xCE, 0x2E, 0xAE, 0x6E, 0xEE, 0x1E,
	0x9E, 0x5E, 0xDE, 0x3E, 0xBE, 0x7E, 0xFE, 0x01
};
   
/**************************************************************************************************/
/*                                      FUNCTION DEFINITIONS                                      */
/**************************************************************************************************/


/*------------------------------------------------------------------------------------------------*/
/* Function     :  ConfigureSPI                                               					  */
/*                                                                            					  */
/* Description  :  Configure SPI to drive display                             					  */
/*                                                                            					  */
/* Arguments    :  None                                                       					  */
/*                                                                            					  */
/* Returns      :  None                                                       					  */
/*------------------------------------------------------------------------------------------------*/

void ConfigureSPI( void )
{
	volatile short TossIt;

	SPI1CON1Lbits.SPIEN = 0;   // Turn off SPI1 during config
	IEC0bits.SPI1IE     = 0;   // Turn off SPI1 interrupt
	IEC0bits.SPI1TXIE   = 0;   // Turn off SPI1 transmit interrupt
	IEC3bits.SPI1RXIE   = 0;   // Turn off SPI1 receive interrupt

	SPI1CON1L = 0x2131;
		// SPIEN    = 0   SPI module off, for now
		// SPISIDL  = 1   SPI halts in IDLE
		// DISSDO   = 0   SDOx pin controlled by module
		// MODE32   = 0   8-bit communication
		// MODE16   = 0   8-bit communication
		// SMP      = 0   Input data sampled at middle of output time (not used)
		// CKE      = 1   Transmit on transition from active to idle clock
		// SSEN     = 0   SS1n pin is controlled by port I/O (not used by SPI)
		// CKP      = 0   Idle state for clock is low, active is high
		// MSTEN    = 1   Master mode
		// DISSDI   = 1   SDIx pin controlled by I/O (not used by SPI)
		// DISSCK   = 0   SCKx pin controlled by module
		// MCLKEN   = 0   PBCLK is used by BRG
		// SPIFE    = 0   Frame pulse precedes first clock (not used)
		// ENHBUF   = 1   Enhanced buffer mode

	SPI1CON1H = 0x0000;     // Audio mode and frame sync not used
	SPI1CON2L = 0x0000;     // Use 16-bit length specified by MODE32 and MODE16
	SPI1STATL = 0x0000;     // Clear SPI status
	SPI1STATH = 0x0000;     // Clear SPI status

	while ( !SPI1STATLbits.SPIRBE )  // While receive buffer not empty
	TossIt = SPI1BUFL;            // Read a word and dump it

	SPI1BRGL  = 7;             // SPI-Baud = FCY/(2*(BRG+1)) - e.g. [7]: "16MHz -> 1MHz"

	SPI1IMSKL = 0x0008;        // Generate interrupt on TX FIFO empty
	SPI1IMSKH = 0x0000;

	IFS0bits.SPI1IF     = 0;   // Clear SPI1 interrupt
	IFS0bits.SPI1TXIF   = 0;   // Clear SPI1 transmit interrupt
	IFS3bits.SPI1RXIF   = 0;   // Clear SPI1 receive interrupt

	// Set up re-mappable pins (peripheral pin select) for SPI
	__builtin_write_OSCCONL(OSCCON & 0xBF);   // Unlock peripheral pin select
	RPOR5bits.RP11R   = 7;     // SPI1 MOSI on RP11
	RPOR6bits.RP12R   = 8;     // SPI1 SCLK on RP12
	__builtin_write_OSCCONL(OSCCON | 0x40);   // Lock peripheral pin select

	SPI1CON1Lbits.SPIEN = 1;   // Enable SPI

	return;
} /* ConfigureSPI */


/*------------------------------------------------------------------------------------------------*/
/* Function     :  DISP_On                                                  					  */
/*                                                                            					  */
/* Description  :  Start LCD display                                          					  */
/*                                                                            					  */
/* Arguments    :  None                                                       					  */
/*                                                                            					  */
/* Returns      :  None                                                       					  */
/*------------------------------------------------------------------------------------------------*/

void DISP_On( void )
{
	if ( DisplayRunning )
	{
		return;
	}

	if ( !SPI1CON1Lbits.SPIEN )
	{
		ConfigureSPI();
	}

	IEC0bits.SPI1TXIE = 0;  							// Turn off SPI1 transmit interrupt

	// Clear both buffers
	memset((char *)BUF0PTR, 0x00, 2*DISP_BUF_SIZE );

	DCSn = 1;               							// Display chip select high
	__delay_us(6);          							// 6us tsSCS delay
	SPI1BUFL = DISP_CLEAR;  							// Display memory clear command
	SPI1BUFL = 0x00;        							// Dummy byte
	while ( !SPI1STATLbits.SRMT );   					// Wait for transmit complete
	__delay_us(2);          							// 2us thSCS delay
	DCSn = 0;               							// Display chip select low

	DisplayWorkBuf = 0;     							// Working display buffer (to write to)
														// other buffer is written to display

	__delay_us(1);         	 							// 1us delay
	DISP = 1;               							// Enable display

	IFS0bits.SPI1TXIF = 0;  							// Clear SPI1 transmit interrupt

	DisplayRunning = true;

	return;
} /* DISP_On */


/*------------------------------------------------------------------------------------------------*/
/* Function     :  DISP_Off                                                 					  */
/*                                                                            					  */
/* Description  :  Turn LCD display off                                       					  */
/*                                                                            					  */
/* Arguments    :  None                                                       					  */
/*                                                                            					  */
/* Returns      :  None                                                       					  */
/*------------------------------------------------------------------------------------------------*/

void DISP_Off( void )
{
	if ( DisplayRunning )
	{
		IEC0bits.SPI1TXIE = 0;  						// Turn off SPI1 transmit interrupt
		DCSn = 1;               						// Display chip select high
		__delay_us(6);          						// 6us tsSCS delay
		SPI1BUFL = DISP_CLEAR;  						// Display memory clear command
		SPI1BUFL = 0x00;        						// Dummy byte
		while ( !SPI1STATLbits.SRMT );   				// Wait for transmit complete
		__delay_us(2);          						// 2us thSCS delay
		DCSn = 0;               						// Display chip select low

		__delay_us(1);          						// 1us delay
		DISP = 0;               						// Disable display
		IFS0bits.SPI1TXIF = 0;  						// Clear SPI1 transmit interrupt
	}

	DisplayRunning = false;

	return;
} /* DISP_Off */


/*------------------------------------------------------------------------------------------------*/
/* Function     :  DISP_Print                                            						  */
/*                                                                            					  */
/* Description  :  x			                               									  */
/*                                                                            					  */
/* Arguments    :  None                                                       					  */
/*                                                                            					  */
/* Returns      :  None                                                       					  */
/*------------------------------------------------------------------------------------------------*/

void DISP_Print( void )
{
	sprintf( TempStr, "%02d.%02d\260C", Temp/100, Temp%100 );
	sprintf( RHStr, "%02d.%02d%%", RH/100, RH%100 );
	WriteString( 11, 10, &MonoBold24_FontInfo, TempStr );
	WriteString( 48, 10, &MonoBold24_FontInfo, RHStr );
	WriteString( 85, 10, &MonoBold24_FontInfo, TimeStr );

	UpdateDisplay = true;

	return;
}


/*------------------------------------------------------------------------------------------------*/
/* Function     :  ClearDisplayBuf                                            					  */
/*                                                                            					  */
/* Description  :  Clear working display buffer                               					  */
/*                                                                            					  */
/* Arguments    :  None                                                       					  */
/*                                                                            					  */
/* Returns      :  None                                                       					  */
/*------------------------------------------------------------------------------------------------*/

void ClearDisplayBuf( void )
{
	int y;
	uint16_t *ptr;

	ptr = (uint16_t *)(&DisplayBuf[DisplayWorkBuf][0][0]);
	for ( y = (DISP_XWORDS*DISP_YSIZE); y; y-- )
		*ptr++ = 0x0000;

	//memset((char *)(&DisplayBuf[DisplayWorkBuf][0][0]), 0x00, DISP_BUF_SIZE );

	return;
} /* ClearDisplayBuf */


/*------------------------------------------------------------------------------------------------*/
/* Function     :  CopyDisplayBuf                                             					  */
/*                                                                            					  */
/* Description  :  Copy writing (displayed) buffer to working buffer          					  */
/*                                                                            					  */
/* Arguments    :  None                                                       					  */
/*                                                                            					  */
/* Returns      :  None                                                       					  */
/*------------------------------------------------------------------------------------------------*/

void CopyDisplayBuf( void )
{
	memcpy( (char *)(&DisplayBuf[DisplayWorkBuf][0][0]),
			(char *)(&DisplayBuf[DisplayWorkBuf^0x1][0][0]), DISP_BUF_SIZE );

	return;
} /* CopyDisplayBuf */


/*------------------------------------------------------------------------------------------------*/
/* Function     :  DisplayRefresh                                             					  */
/*                                                                            					  */
/* Description  :  Refresh LCD display (toggle COM on LCD) by writing         					  */
/*                 command to display from memory, or if UpdateDisplay flag   					  */
/*                 is set, by writing new data to display. Operation is       					  */
/*                 completed by _SPI1Interrupt.                               					  */
/*                                                                            					  */
/* Arguments    :  None                                                       					  */
/*                                                                            					  */
/* Returns      :  None                                                       					  */
/*------------------------------------------------------------------------------------------------*/

void DisplayRefresh( void )
{
	DCSn = 1;               // Display chip select high
	__delay_us(6);          // 6us tsSCS delay
	IEC0bits.SPI1TXIE = 1;  // Turn on SPI1 transmit interrupt

	if ( UpdateDisplay )
	{
		DisplayData   = (uint8_t *)(&DisplayBuf[DisplayWorkBuf][0][0]);
		DisplayWorkBuf ^= 0x1;     // Toggle working and output buffers
		DisplayAddr   = GateLine;  // Address of first display line
		DisplayLine   = 0;
		DisplayByte   = 0;
		SPI1BUFL = DISP_WRITE;
		SPI1BUFL = *DisplayAddr++;
	}
	else
	{
		SPI1BUFL = DISP_HOLD;   // Display from LCD memory
		SPI1BUFL = 0x00;        // Dummy byte
	}

	return;
} /* DisplayRefresh */


/*------------------------------------------------------------------------------------------------*/
/* Function     :  _SPI1Interrupt                                             					  */
/*                                                                            					  */
/* Description  :  Interrupt Service Routine for SPI1                         					  */
/*                 Updates LCD display                                        					  */
/*                                                                            					  */
/* Arguments    :  None                                                       					  */
/*                                                                            					  */
/* Returns      :  None                                                       					  */
/*                                                                            					  */
/*------------------------------------------------------------------------------------------------*/

void _PSV_ _SPI1TXInterrupt( void )
{
	if ( UpdateDisplay )
	{
		TP2 = 1;
		if ( DisplayLine == DISP_YSIZE )
		{
			SPI1BUFL = 0x00;        // 16 clocks to complete display memory write
			SPI1BUFL = 0x00;
			UpdateDisplay = false;  // Done writing. Next, bring DCSn low
		}
		else
		{
			if ( (!DisplayByte) && (DisplayLine) )
			{
				SPI1BUFL = DISP_WRITE;
				SPI1BUFL = *DisplayAddr++;
			}

			while ( (!SPI1STATLbits.SPITBF) && (DisplayByte < DISP_XBYTES) )
			{
				SPI1BUFL = ~(*DisplayData++);  // Invert for SHARP Memory Display
				DisplayByte++;
			}

			if ( DisplayByte == DISP_XBYTES )
			{
				DisplayByte = 0;
				DisplayLine++;
			}
		}
		TP2 = 0;
	}
	else
	{
		IEC0bits.SPI1TXIE = 0;  // Turn off SPI1 transmit interrupt
		while ( !SPI1STATLbits.SRMT );   // Wait for transmit complete
		__delay_us(2);          // 2us thSCS delay
		DCSn = 0;               // Display chip select low
	}

	IFS0bits.SPI1TXIF   = 0;   // Clear SPI1 transmit interrupt

	return;
} /* _SPI1Interrupt */


/*------------------------------------------------------------------------------------------------*/
/* Function     :  WriteChar                                                  					  */
/*                                                                            					  */
/* Description  :  Write a character to display buffer at given position      					  */
/*                                                                            					  */
/*  Arguments    : YTop  - line (y) coord of top of character                 					  */
/*                 XLeft - column (x) coord of left of character              					  */
/*                 Font  - pointer to font info structure                     					  */
/*                 ch    - character to write                                					  */
/*                                                                            					  */
/* Returns      :  new XLeft, adjusted for width of character                 					  */
/*------------------------------------------------------------------------------------------------*/

int WriteChar( int YTop, int XLeft, const FONT_INFO *Font, uint8_t ch )
{
	int MaskWidthBytes, Offset, StartXByte, i, j, b, w, x, y;
	int CharWidth, CharWidthBytes;
	uint8_t Data;
	const uint8_t *ptr;
	uint8_t Mask[16];

	StartXByte = XLeft >> 3;
	Offset = XLeft % 8;

	ptr = &(Font->data[Font->charInfo[ch - (Font->startChar)].offset]);
	CharWidth = Font->charInfo[ch - (Font->startChar)].widthBits;

	if ( (CharWidth + Offset) <= 8 )
	{
		Mask[0] = (0xFF >> (CharWidth + Offset)) | (~(0xFF >> Offset));
		MaskWidthBytes = 1;
	}
	else
	{
		w = CharWidth + Offset - 8;
		MaskWidthBytes = 1;
		Mask[0] = ~(0xFF >> Offset);
		while ( w >= 8 )
		{
			Mask[MaskWidthBytes++] = 0x00;
			w -= 8;
		}
		if ( w )
			Mask[MaskWidthBytes++] = 0xFF >> w;
	}

	CharWidthBytes = (CharWidth+7) >> 3;
	for ( j = 0, y = YTop; j < Font->height; j++, y++)
	{
		for ( i = 0, x = StartXByte, b = 0; i < MaskWidthBytes; i++, x++ )
		{
			if ( i )
			{
				Data = *ptr++ << (8-Offset);
				b++;
			}
			else
				Data = 0x00;
			if ( b < CharWidthBytes )
			{
				Data |= *ptr >> Offset;
				if ( i == (MaskWidthBytes-1) )
					ptr++;
			}

			if ((y < DISP_YSIZE) && (x < DISP_XBYTES))
			{
				DisplayBuf[DisplayWorkBuf][y][x] &= Mask[i];
				DisplayBuf[DisplayWorkBuf][y][x] |= Data;
			}
		}
	}

	return (XLeft + CharWidth);
} /* WriteChar */


/*------------------------------------------------------------------------------------------------*/
/* Function     :  WriteGap                                                   					  */
/*                                                                            					  */
/* Description  :  Write a gap between characters at given position           					  */
/*                                                                            					  */
/*  Arguments    : YTop  - line (y) coord of top of character                 					  */
/*                 XLeft - column (x) coord of left of character              					  */
/*                 Font  - pointer to font info structure                     					  */
/*                                                                            					  */
/* Returns      :  new XLeft, adjusted for width of gap                       					  */
/*------------------------------------------------------------------------------------------------*/

int WriteGap( int YTop, int XLeft, const FONT_INFO *Font )
{
	int MaskWidthBytes, Offset, StartXByte, i, j, w, x, y;
	int GapWidth, GapWidthBytes;
	uint8_t Mask[3];

	StartXByte = XLeft >> 3;
	Offset = XLeft % 8;
	GapWidth = Font->gapPixels;

	if ( (GapWidth + Offset) <= 8 )
	{
		Mask[0] = (0xFF >> (GapWidth + Offset)) | (~(0xFF >> Offset));
		MaskWidthBytes = 1;
	}
	else
	{
		w = GapWidth + Offset - 8;
		MaskWidthBytes = 1;
		Mask[0] = ~(0xFF >> Offset);
		while ( w >= 8 )
		{
			Mask[MaskWidthBytes++] = 0x00;
			w -= 8;
		}
		if ( w )
			Mask[MaskWidthBytes++] = 0xFF >> w;
	}

	GapWidthBytes = (GapWidth+7) >> 3;
	for ( j = 0, y = YTop; j < Font->height; j++, y++)
	{
		for ( i = 0, x = StartXByte; i < MaskWidthBytes; i++, x++ )
		{
			if ((y < DISP_YSIZE) && (x < DISP_XBYTES))
				DisplayBuf[DisplayWorkBuf][y][x] &= Mask[i];
		}
	}

	return (XLeft + GapWidth);
} /* WriteGap */


/*------------------------------------------------------------------------------------------------*/
/* Function     :  WriteString                                                					  */
/*                                                                            					  */
/* Description  :  Write a string of characters at given position             					  */
/*                                                                            					  */
/*  Arguments    : YTop  - line (y) coord of top of character                 					  */
/*                 XLeft - column (x) coord of left of character              					  */
/*                 Font  - pointer to font info structure                     					  */
/*                 str   - string to write                                    					  */
/*                                                                            					  */
/* Returns      :  new XLeft, adjusted for width string                       					  */
/*------------------------------------------------------------------------------------------------*/

int WriteString( int YTop, int XLeft, const FONT_INFO *Font, char *str )
{
	while ( *str && (XLeft < DISP_XSIZE) )
	{
		XLeft = WriteChar( YTop, XLeft, Font, (uint8_t)(*str++) );
		if ( *str )
			XLeft = WriteGap( YTop, XLeft, Font );
	}

	return XLeft;
} /* WriteStrings */


/*------------------------------------------------------------------------------------------------*/
/* Function     :  StringWidth                                                					  */
/*                                                                            					  */
/* Description  :  Return pixel width of a string of characters               					  */
/*                                                                            					  */
/*  Arguments    : str - string to calculate width for                        					  */
/*                 Font  - pointer to font info structure                     					  */
/*                                                                            					  */
/* Returns      :  width of string in pixels                                  					  */
/*------------------------------------------------------------------------------------------------*/

int StringWidth( char *str, const FONT_INFO *Font )
{
	int Width;

	Width = 0;
	while ( *str )
	{
		Width += Font->charInfo[(*str++) - (Font->startChar)].widthBits;
		if ( *str )
			Width += Font->gapPixels;
	}

	return Width;
} /* StringWidth */

/**************************************************************************************************/
