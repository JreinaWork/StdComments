/**************************************************************************************************/
/* Title        :  EGMM Buttons                                                                   */
/*------------------------------------------------------------------------------------------------*/
/* File         :  Buttons.c                                                                      */
/* Author       :  Daniel Morris                                                                  */
/* Company      :  Intellectual Ventures Laboratory                                               */
/* Project      :  MAISE EGMM Proof of Concept Device (De-risk testing)                           */
/* Created      :  12 Sep 2018                                                                    */
/* Last update  :  12 Sep 2018                                                                    */
/* Compiler     :  Microchip MPLAB XC16, Ver. 1.33                                                */
/* Target       :  PIC24FJ256GA702-I/ML                                                           */
/*------------------------------------------------------------------------------------------------*/
/* Description  :  Routines to control the button interaction and use                             */
/*------------------------------------------------------------------------------------------------*/
/* Copyright    :  (c) 2018 Intellectual Ventures  All rights reserved                            */
/**************************************************************************************************/

#define BUTTONS_C

/**************************************************************************************************/
/*                                         INCLUDES                                               */
/**************************************************************************************************/

//Project
#include "Globals.h"


/*------------------------------------------------------------------------------------------------*/
/* Function     :  KeysInit                                                   					  */
/*                                                                            					  */
/* Description  :  Initialization of keys for use                             					  */
/*                                                                            					  */
/* Arguments    :  None                                                       					  */
/*                                                                            					  */
/* Returns      :  None                                                       					  */
/*------------------------------------------------------------------------------------------------*/

void KeysInit( void )
{
	return;							//put contents here if needed for initial configuration
} /* KeysInit */


/*------------------------------------------------------------------------------------------------*/
/* Function     :  Key1Read ('B')                                             					  */
/*                                                                            					  */
/* Description  :  Read the value of key 1                                    					  */
/*                                                                            					  */
/* Note         :  Connected to 'S1', labeled 'X2', connects to RB14          					  */
/*                                                                            					  */
/* Arguments    :  None                                                       					  */
/*                                                                            					  */
/* Returns      :  (bool) value of pin                                        					  */
/*------------------------------------------------------------------------------------------------*/

bool Key1Read( void )
{
	uint16_t val = CMSTATbits.C3OUT;

	return (val == 0);
} /* Key1Read */


/*------------------------------------------------------------------------------------------------*/
/* Function     :  Key2Read ('A')                                             					  */
/*                                                                            					  */
/* Description  :  Read the value of key 2                                    					  */
/*                                                                            					  */
/* Note         :  Connected to 'S2', labeled 'X1', connects to RB13          					  */
/*                                                                            					  */
/* Arguments    :  None                                                       					  */
/*                                                                            					  */
/* Returns      :  (bool) value of pin                                        					  */
/*------------------------------------------------------------------------------------------------*/

bool Key2Read( void )
{
	uint16_t val = PORTBbits.RB13;

	return (val == 0);
} /* Key2Read */


/**************************************************************************************************/
