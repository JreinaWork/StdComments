/**************************************************************************************************/
/* Title        :  EGMM Display                                                                   */
/*------------------------------------------------------------------------------------------------*/
/* File         :  Display.h                                                                      */
/* Author       :  Daniel Morris                                                                  */
/* Company      :  Intellectual Ventures Laboratory                                               */
/* Project      :  MAISE EGMM Proof of Concept Device (De-risk testing)                           */
/* Created      :  12 Sep 2018                                                                    */
/* Last update  :  12 Sep 2018                                                                    */
/* Compiler     :  Microchip MPLAB XC16, Ver. 1.33                                                */
/* Target       :  PIC24FJ256GA702-I/ML                                                           */
/*------------------------------------------------------------------------------------------------*/
/* Description  :  Routines to start up and run LCD display via SPI                               */
/*------------------------------------------------------------------------------------------------*/
/* Copyright    :  (c) 2018 Intellectual Ventures  All rights reserved                            */
/**************************************************************************************************/

#ifndef DISPLAY_H
#define	DISPLAY_H

/**************************************************************************************************/
/*                                           INCLUDES                                             */
/**************************************************************************************************/

//Project
#include "Globals.h"

/**************************************************************************************************/
/*                                            DEFINES                                             */
/**************************************************************************************************/

#define DISP_YSIZE  (128)
#define DISP_XSIZE  (128)
#define DISP_XBYTES (DISP_XSIZE/8)
#define DISP_XWORDS (DISP_XSIZE/16)
#define DISP_BUF_SIZE  (DISP_YSIZE*DISP_XBYTES)

/**************************************************************************************************/
/*                                      GLOBAL VARIABLES                                          */
/**************************************************************************************************/

extern bool DisplayRunning;
extern volatile bool UpdateDisplay;

/**************************************************************************************************/
/*                                      FUNCTION DECLARATIONS                                     */
/**************************************************************************************************/

void DISP_On( void );
void DISP_Off( void );
void ClearDisplayBuf( void );
void CopyDisplayBuf( void );
void DisplayRefresh( void );
int WriteChar( int YTop, int XLeft, const FONT_INFO *Font, uint8_t ch );
int WriteString( int YTop, int XLeft, const FONT_INFO *Font, char *str );
int StringWidth( char *str, const FONT_INFO *Font );

/**************************************************************************************************/
/*                                      GLOBAL FUNCTIONS                                          */
/**************************************************************************************************/

extern void DISP_Print( void );

/**************************************************************************************************/

#endif	/* DISPLAY_H */

