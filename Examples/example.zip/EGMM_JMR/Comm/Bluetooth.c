/**************************************************************************************************/
/* Title        :  EGMM Bluetooth Interface                                                       */
/*------------------------------------------------------------------------------------------------*/
/* File         :  Bluetooth.c                                                                    */
/* Author       :  Daniel Morris                                                                  */
/* Company      :  Intellectual Ventures Laboratory                                               */
/* Project      :  MAISE EGMM Proof of Concept Device (De-risk testing)                           */
/* Created      :  12 Sep 2018                                                                    */
/* Compiler     :  Microchip MPLAB XC16, Ver. 1.33                                                */
/* Target       :  PIC24FJ256GA702-I/ML                                                           */
/*------------------------------------------------------------------------------------------------*/
/* Description  :  Bluetooth Interface (Transparent UART)                                         */
/*------------------------------------------------------------------------------------------------*/
/* Copyright    :  (c) 2018 Intellectual Ventures  All rights reserved                            */
/**************************************************************************************************/

#define BLUETOOTH_C

/**************************************************************************************************/
/*                                         INCLUDES                                               */
/**************************************************************************************************/

//Project
#include "Globals.h"

/**************************************************************************************************/
/*                                          DEFINES                                               */
/**************************************************************************************************/

// Transmit Buffer Macros
#define TX_BUF_LEN      (256)    // Transmit buffer length. Must be a power of 2
#define TxBufFull()		(((TxBufEnd + 1) & (TX_BUF_LEN-1)) == TxBufStart)
#define TxBufEmpty()	(TxBufStart == TxBufEnd)

/* Receive Buffer Macros */
#define RX_BUF_LEN      (64)     // Receive buffer length. Must be a power of 2
#define RxBufFull()		(((RxBufEnd + 1) & (RX_BUF_LEN-1)) == RxBufStart)
#define RxBufEmpty()	(RxBufStart == RxBufEnd)

/**************************************************************************************************/
/*                                      GLOBAL VARIABLES                                          */
/**************************************************************************************************/
char TxBuf[TX_BUF_LEN];
volatile unsigned char TxBufStart;
volatile unsigned char TxBufEnd;

char RxBuf[RX_BUF_LEN];
volatile unsigned char RxBufStart;
volatile unsigned char RxBufEnd;


/**************************************************************************************************/
/*                                      FUNCTION DEFINITIONS                                      */
/**************************************************************************************************/

/*------------------------------------------------------------------------------------------------*/
/* Function     :  ConfigureUART                                              					  */
/*                                                                            					  */
/* Description  :  Initializes UART. Baud rate is set by #define              					  */
/*                                                                            					  */
/* Arguments    :  None                                                       					  */
/*                                                                            					  */
/* Returns      :  None                                                       					  */
/*                                                                            					  */
/*------------------------------------------------------------------------------------------------*/

void ConfigureUART( void )
{
	unsigned short TossIt;

	IEC0bits.U1RXIE   = 0;  // Disable UART Receive interrupt
	IEC0bits.U1TXIE   = 0;  // Disable UART Transmit interrupt

	// Empty transmit Buffer
	TxBufStart = 0;
	TxBufEnd = 0;

	// Empty receive Buffer
	RxBufStart = 0;
	RxBufEnd = 0;

	U1MODE = 0x2800;
	// UARTEN = 0   UART is disabled(temporarily)
	// USIDL  = 1   Stop in idle mode
	// IREN   = 0   IrDA encoder/decoder are disabled
	// RTSMD  = 1   U1RTSn PIN is in simplex
	// UEN    = 0   U1TX, U1RX, are enabled U1CTS and U1RTS are port I/O
	// WAKE   = 0   Wake up disabled
	// LPBACK = 0   Loop back mode is disabled
	// ABAUD  = 0   Baud rate measurement disabled
	// RXINV  = 0   U1RX idle state is '1'
	// BRGH   = 0   Standard Baud rate mode (generate from Fcy/16)
	// PDSEL  = 0   8 bit data, no parity
	// STSEL  = 0   1 stop bit

	U1STA = 0x8110;
	// UTXISEL1 = 1   Interrupt when TX buffer is empty (UTXISEL<1:0>=0x02)
	// UTXINV   = 0   U1TX idle state is '1' (IREN=0)
	// UTXISEL1 = 0   Interrupt when TX buffer is empty (UTXISEL<1:0>=0x02)
	// URXEN    = 0   Receive is enabled, U1RX is controlled by UART1
	// UTXBRK   = 0   U1TX pin operates normally (sync break disabled)
	// UTXEN    = 0   UART transmitter pin enabled
	// UTXBF    = 0   UART TX buffer full (read only)
	// TRMT     = 1   UART TX shift register is empty (read only)
	// URXISEL  = 0   UART RX interrupt flag set when a character is received
	// ADDEN    = 0   Address detect mode disabled
	// RIDLE    = 1   Receiver is idle (read only)
	// PERR     = 0   Parity error not detected (read only)
	// FERR     = 0   Framing error not detected (read only)
	// OERR     = 0   Receive buffer overrun error not detected (read only)
	// URXDA    = 0   Receive buffer is empty (read only)

	// Set up baud rate
	U1BRG = BRG_VAL(115200L);

	// Clear U1 RX REG
	while (U1STAbits.URXDA)
		TossIt = U1RXREG;

	// Set up remappable pins (peripheral pin select)
	__builtin_write_OSCCONL(OSCCON & 0xBF);   // Unlock peripheral pin select
	RPOR4bits.RP8R    = 3;     // U1TX (BTRXD) mapped to RP8
	RPINR18bits.U1RXR = 7;     // U1RX (BTTXD) mapped to RP7
	__builtin_write_OSCCONL(OSCCON | 0x40);   // Lock peripheral pin select

	// Turn on interrupts, enable UART
	IEC0bits.U1RXIE   = 1;  // Enable UART Receive interrupt
	U1MODEbits.UARTEN = 1;  // Enable UART
	IFS0bits.U1TXIF   = 0;  // Clear UART1 transmit interrupt flag
	U1STAbits.UTXEN   = 1;  // Enable UART TX (interrupt enabled when xmit)

	return;
}  /* ConfigureUART */



/*------------------------------------------------------------------------------------------------*/
/* Function     :  _U1RXInterrupt                                             					  */
/*                                                                            					  */
/* Description  :  Receive bytes into buffer from UART1                       					  */
/*                                                                            					  */
/* Arguments    :  None                                                       					  */
/*                                                                            					  */
/* Returns      :  None                                                       					  */
/*                                                                            					  */
/*------------------------------------------------------------------------------------------------*/

void _PSV_ _U1RXInterrupt( void )
{

	RxBuf[RxBufEnd] = U1RXREG;       // Reading RCREG clears RCIF
	if ( !RxBufFull() )
	{
		RxBufEnd = (RxBufEnd + 1) & (RX_BUF_LEN-1);
	}

	IFS0bits.U1RXIF = 0;             // Reset UART1 rx-int flag & return

	return;
}  /* _U1RXInterrupt */


/*------------------------------------------------------------------------------------------------*/
/* Function     :  _U1TXInterrupt                                             					  */
/*                                                                            					  */
/* Description  :  Receive bytes into buffer from UART1                       					  */
/*                                                                            					  */
/* Arguments    :  None                                                       					  */
/*                                                                            					  */
/* Returns      :  None                                                       					  */
/*                                                                            					  */
/*------------------------------------------------------------------------------------------------*/

void _PSV_ _U1TXInterrupt( void )
{

	/* UART Transmit Interrupt */
	if ( !TxBufEmpty() )
	{
		if ( !U1STAbits.UTXBF )
		{
			U1TXREG = TxBuf[TxBufStart];
			TxBufStart = (TxBufStart + 1) & (TX_BUF_LEN-1);
		}
	}
	else  /* TX buffer empty, turn off transmit */
	{
		while ( IEC0bits.U1TXIE )
			IEC0bits.U1TXIE = 0;
	}

	IFS0bits.U1TXIF = 0;    							// Reset UART1 transmit interrupt flag

	return;
}  /* _U1TXInterrupt */



/*------------------------------------------------------------------------------------------------*/
/* Function     :  kbhit                                                      					  */
/*                                                                            					  */
/* Description  :  Returns TRUE (1) if a character is available in the UART1  					  */
/*                 receive buffer, otherwise returns FALSE (0).               					  */
/*                                                                            					  */
/* Arguments    :  None                                                       					  */
/*                                                                            					  */
/* Returns      :  TRUE if a character is available, FALSE otherwise.         					  */
/*                 Return type is 'bit' instead of 'boolean' to match         					  */
/*                 conio.h declaration.                                       					  */
/*                                                                            					  */
/*------------------------------------------------------------------------------------------------*/

bool kbhit( void )
{
	return (RxBufEmpty()) ? false : true;
}  /* kbhit */



/* "Helper Functions" allowing use of stdio functions */

/*------------------------------------------------------------------------------------------------*/
/* Function     : open                                                        					  */
/*                                                                            					  */
/* Description  : x                                                           					  */
/*                                                                            					  */
/* Arguments    : none                                                        					  */
/*                                                                            					  */
/* Returns      : never returns                                               					  */
/*                                                                           					  */
/*------------------------------------------------------------------------------------------------*/

int _LIBC_ open( const char *name, int access, int mode )
{
switch ( name[0] )
	{
		case 'i':
			return handle_stdin;
		case 'o':
			return handle_stdout;
		case 'e':
			return handle_stderr;
		default:
			return handle_stderr;
	}
} /* open */


/*------------------------------------------------------------------------------------------------*/
/* Function     : close                                                       					  */
/*                                                                            					  */
/* Description  : x                                                           					  */
/*                                                                            					  */
/* Arguments    : none                                                        					  */
/*                                                                            					  */
/* Returns      : never returns                                               					  */
/*                                                                            					  */
/*------------------------------------------------------------------------------------------------*/

int _LIBC_ close( int handle )
{
	// Disable UART, turn off interrupts,
	U1MODEbits.UARTEN = 0;  // Disable UART
	U1STAbits.UTXEN   = 0;  // Disable TX
	IEC0bits.U1RXIE   = 0;  // Disable UART Receive interrupt
	IEC0bits.U1TXIE   = 0;  // Disable UART Transmit interrupt

	return handle;
} /* close */


/*------------------------------------------------------------------------------------------------*/
/* Function     : BRG_VAL                                                      					  */
/*                                                                            					  */
/* Description  : Baud Rate Generator divider value - formula - set BAUD_RATE to change			  */
/*                                                                            					  */
/* Arguments    : unsigned long bps - baud rate (bits per second)                                 */
/*                                                                            					  */
/* Returns      : none                                                					          */
/*                                                                            					  */
/*------------------------------------------------------------------------------------------------*/

uint16_t BRG_VAL( unsigned long bps )
{
	uint16_t a   = (2L*OSCILLATOR_GetRate())/(16L*bps);
	uint16_t b   = (a+1L)/2L;
	uint16_t val = (b-1L);

	return val;
}


/*------------------------------------------------------------------------------------------------*/
/* Function     : write                                                       					  */
/*                                                                            					  */
/* Description  : x                                                           					  */
/*                                                                            					  */
/* Arguments    : none                                                        					  */
/*                                                                            					  */
/* Returns      : never returns                                               					  */
/*                                                                            					  */
/*------------------------------------------------------------------------------------------------*/

int _LIBC_ write( int handle, void *buffer, unsigned int len )
{
	unsigned char TxNext;
	int i;

	switch( handle )
	{
		case 0:  // stdin  (UART1)
		case 1:  // stdout (UART1)
		case 2:  // stderr (UART1)
		default:
			if ( !U1MODEbits.UARTEN )
				ConfigureUART();
			for ( i = len; i; --i)
			{
				TxNext = (TxBufEnd + 1) & (TX_BUF_LEN-1);
				while (TxNext == TxBufStart);    // Wait for space in buffer, if necessary

				while ( IEC0bits.U1TXIE )  // Disable interrupt while adding ch to buffer
					IEC0bits.U1TXIE = 0;

				TxBuf[TxBufEnd] = *(char *)buffer++;   // Put character in transmit buffer
				TxBufEnd = TxNext;                     // Increment buffer pointer

				//   if ( U1STAbits.TRMT )
				IFS0bits.U1TXIF = 1;       // Set UART1 transmit interrupt flag if Tx empty
				IEC0bits.U1TXIE = 1;       // Re-enable interrupt
			}
			return len;
	}
} /* write */


/*------------------------------------------------------------------------------------------------*/
/* Function     : read                                                        					  */
/*                                                                            					  */
/* Description  : x                                                           					  */
/*                                                                            					  */
/* Arguments    : none                                                        					  */
/*                                                                            					  */
/* Returns      : never returns                                               					  */
/*                                                                            					  */
/*------------------------------------------------------------------------------------------------*/

int _LIBC_ read( int handle, void *buffer, unsigned int len )
{
	int charsread;

	switch( handle )
	{
		case 0:  // stdin  (UART1)
		default:
			if ( !U1MODEbits.UARTEN )
			ConfigureUART();
			while ( len && !RxBufEmpty() )
			{
				*(char *)buffer++ = RxBuf[RxBufStart];
				RxBufStart = (RxBufStart + 1) & (RX_BUF_LEN-1);
				charsread++;
				len--;
			}
			return charsread;
	}
} /* read */

/**************************************************************************************************/
