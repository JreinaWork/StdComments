/**************************************************************************************************/
/* Title        :  EGMM_POC Main                                                                  */
/*------------------------------------------------------------------------------------------------*/
/* File         :  Main.h                                                                        */
/* Author       :  Daniel Morris                                                                  */
/* Company      :  Intellectual Ventures Laboratory                                               */
/* Project      :  MAISE EGMM Proof of Concept Device (De-risk testing)                           */
/* Created      :  12 Sep 2018                                                                    */
/* Last update  :  12 Sep 2018                                                                    */
/* Compiler     :  Microchip MPLAB XC16, Ver. 1.33                                                */
/* Target       :  PIC24FJ256GA702-I/ML                                                           */
/*------------------------------------------------------------------------------------------------*/
/* Description  :  Startup and main loop                                                          */
/*------------------------------------------------------------------------------------------------*/
/* Copyright    :  (c) 2018 Intellectual Ventures  All rights reserved                            */
/**************************************************************************************************/

#ifndef GLOBALS_H
#define	GLOBALS_H

/**************************************************************************************************/
/*                                           INCLUDES                                             */
/**************************************************************************************************/

//Library
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include <math.h>
#include <libpic30.h>

//Project
#ifndef _COMPILE_WITH_ECLIPSE_
	#include <xc.h>
#else
	#include "xc/p24FJ256GA702.h"
#endif
#include "UI/Fonts.h"
#include "UI/Buttons.h"
#include "UI/Display.h"
#include "Comm/Bluetooth.h"
#include "Sensor/DataAcq.h"
#include "Sensor/GMD.h"
#include "System/System.h"
#include "System/Clocks.h"

/**************************************************************************************************/
/*                                           VERSIONS                                             */
/**************************************************************************************************/

// Version 0.6.5*
#define FW_MAJOR    (0)
#define FW_MINOR    (6)
#define FW_REVISION (5)

/**************************************************************************************************/
/*                                     HARDWARE CONFIGURATION                                     */
/**************************************************************************************************/

#define HW_REV  	(02)                            	// TI HDC1080 sensor

/**************************************************************************************************/
/*                                            DEFINES                                             */
/**************************************************************************************************/

#define SLEEP_LIM_S	(45*60)								// Time cap to enter sleep

// PIN Definitions
#define TP1         (PORTBbits.RB1)
#define TP2         (PORTBbits.RB0)
#define TP3         (PORTAbits.RA2)
#define TP4         (PORTAbits.RA3)

#define KEYSENSE    (PORTBbits.RB14)
#define PWRENBL     (PORTBbits.RB15)
#define BTRSTn      (PORTBbits.RB6)
#define BTMODE      (PORTBbits.RB5)
#define DISP        (PORTBbits.RB9)
#define DCSn        (PORTBbits.RB10)

// Pins assigned to peripherals
#define SDA         (PORTBbits.RB3)
#define SCL         (PORTBbits.RB4)
#define BTRXD       (PORTBbits.RB8)
#define BTTXD       (PORTBbits.RB7)
#define MOSI        (PORTBbits.RB11)
#define SCLK        (PORTBbits.RB12)

//Function attributes
#define _PSV_   __attribute__((__interrupt__(no_auto_psv)))
#define _LIBC_  __attribute__((__weak__, __section__(".libc")))
#define _BOOT_  __attribute__((user_init))

/**************************************************************************************************/
/*                                       GLOBAL VARIABLES                                         */
/**************************************************************************************************/
extern uint16_t RH;
extern uint16_t Temp;

extern char TimeStr[10];
extern char RHStr[10];
extern char TempStr[10];



/**************************************************************************************************/

#endif	/* GLOBALS_H */

