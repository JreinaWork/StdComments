/**************************************************************************************************/
/* Title        :  EGMM clock & timing                                                   	 	  */
/*------------------------------------------------------------------------------------------------*/
/* File         :  Clocks.c                                                                       */
/* Author       :  Justin Reina                                                                   */
/* Company      :  Intellectual Ventures Laboratory                                               */
/* Project      :  MAISE EGMM Proof of Concept Device (De-risk testing)                           */
/* Created      :  06 Apr 2018                                                                    */
/* Compiler     :  Microchip MPLAB XC16, Ver. 1.33                                                */
/* Target       :  PIC24FJ256GA702-I/ML                                                           */
/*------------------------------------------------------------------------------------------------*/
/* Description  :  x                                                                              */
/*------------------------------------------------------------------------------------------------*/
/* Copyright    :  (c) 2018 Intellectual Ventures  All rights reserved                            */
/**************************************************************************************************/

#define CLOCKS_C

/**************************************************************************************************/
/*                                         INCLUDES                                               */
/**************************************************************************************************/

//Project
#include "Globals.h"

/**************************************************************************************************/
/*                                      GLOBAL VARIABLES                                          */
/**************************************************************************************************/

int Ticks;
int ElapsedTime;
int DaqTime;


/**************************************************************************************************/
/*                                      FUNCTION DEFINITIONS                                      */
/**************************************************************************************************/

/*------------------------------------------------------------------------------------------------*/
/* Function     : CLOCKS_Init                                                 					  */
/*                                                                            					  */
/* Description  : initialize system clocks                                     					  */
/*                                                                            					  */
/* Arguments    : none                                                        					  */
/*                                                                            					  */
/* Returns      : none			                                               					  */
/*                                                                            					  */
/*------------------------------------------------------------------------------------------------*/

void CLOCKS_Init( void )
{
	OSCILLATOR_SetValue(CLOCK_2_MHZ);

	return;
} /* CLOCKS_Init */


/*------------------------------------------------------------------------------------------------*/
/* Function     : __delay_ms                                                        		      */
/*                                                                            					  */
/* Description  : delay for specified milliseconds                             					  */
/*                                                                            					  */
/* Arguments    : unsigned long d - number of milliseconds delay             					  */
/*                                                                            					  */
/* Returns      : none                                                 					          */
/*                                                                            					  */
/*------------------------------------------------------------------------------------------------*/

void __delay_ms( unsigned long d )
{
    __delay_us(d*1000LL);
}


/*------------------------------------------------------------------------------------------------*/
/* Function     : __delay_us                                                   					  */
/*                                                                            					  */
/* Description  : delay for specified microseconds                             					  */
/*                                                                            					  */
/* Arguments    : unsigned long d - number of microseconds delay             					  */
/*                                                                            					  */
/* Returns      : none                                                 					          */
/*                                                                            					  */
/*------------------------------------------------------------------------------------------------*/

void __delay_us(unsigned long d)
{
    // Prep for calc
	uint64_t d_64 = d;
	uint32_t f = OSCILLATOR_GetRate();
	
    // Calc val
    uint32_t val = (d_64*f)/1000000ULL;
    
    //Apply
	__delay32(val);
    
	return;
}


/*------------------------------------------------------------------------------------------------*/
/* Function     : OSCILLATOR_Initialize                                       					  */
/*                                                                            					  */
/* Description  : initialize oscillator to default state                      					  */
/*                (16MHz FCY, 32 MHz Fosc)                                    					  */
/*                                                                            					  */
/* Arguments    : none                                                        					  */
/*                                                                            					  */
/* Returns      : none                                                        					  */
/*                                                                            					  */
/* Post         : Fosc=32MHz, FCY=16MHz										  					  */
/*                                                                            					  */
/*------------------------------------------------------------------------------------------------*/

void OSCILLATOR_Initialize( void )
{
	// CF no clock failure; NOSC FRCPLL; SOSCEN disabled; POSCEN disabled; CLKLOCK unlocked; OSWEN Switch is Complete; IOLOCK not-active;
	OSCCON_Init();
	OSCCON_Write(0x1120);
	// CPDIV 1:1; PLLEN disabled; DOZE 1:8; RCDIV FRC; DOZEN disabled; ROI disabled;
	CLKDIV = 0x3000;
	// STOR disabled; STORPOL Interrupt when STOR is 1; STSIDL disabled; STLPOL Interrupt when STLOCK is 1; STLOCK disabled; STSRC SOSC; STEN disabled; TUN Center frequency;
	OSCTUN = 0x0000;
	// ROEN disabled; ROSEL FOSC; ROSIDL disabled; ROSWEN disabled; ROOUT disabled; ROSLP disabled;
	REFOCONL = 0x0000;
	// RODIV 0;
	REFOCONH = 0x0000;
	// ROTRIM 0;
	REFOTRIML = 0x0000;
	// DCOTUN 0;
	DCOTUN = 0x0000;
	// DCOFSEL 8; DCOEN disabled;
	DCOCON = 0x0700;
	// DIV 0;
	OSCDIV = 0x0000;
	// TRIM 0;
	OSCFDIV = 0x0000;
	//Set value
	OSCILLATOR_SetValue(CLOCK_16_MHZ);

	return;
} /* OSCILLATOR_Initialize */


/*------------------------------------------------------------------------------------------------*/
/* Function     : OSCILLATOR_SetValue                                         					  */
/*                                                                            					  */
/* Description  : set the internal oscillator to a selected value             					  */
/*                                                                            					  */
/* Arguments    : ClockCfg cfg - clock setting to apply                       					  */
/*                                                                            					  */
/* Returns      : none                                                        					  */
/*                                                                            					  */
/*------------------------------------------------------------------------------------------------*/

void OSCILLATOR_SetValue ( ClockCfg cfg )
{
	//Configure Clock
	switch(cfg) {
		case CLOCK_16_MHZ:
			CLKDIV = 0x3000;      //CPDIV 1:1
			break;
		case CLOCK_8_MHZ:
			CLKDIV = 0x3040;      //CPDIV 1:2
			break;
		case CLOCK_4_MHZ:
			CLKDIV = 0x3080;      //CPDIV 1:4
			break;
		case CLOCK_2_MHZ:
			CLKDIV = 0x30C0;      //CPDIV 1:8
			break;
		default:
			for(;;);
	}

	//Update Timer
	PR1  = calcPR1Value(TIMER_PERIOD_MS);  				// Timer 1 period

	return;
} /* OSCILLATOR_SetValue */



/*------------------------------------------------------------------------------------------------*/
/* Function     : OSCILLATOR_GetValue                                         					  */
/*                                                                            					  */
/* Description  : set the internal oscillator to a selected value             					  */
/*                                                                            					  */
/* Arguments    : ClockCfg cfg - clock setting to apply                       					  */
/*                                                                            					  */
/* Returns      : none                                                        					  */
/*                                                                            					  */
/*------------------------------------------------------------------------------------------------*/

ClockCfg OSCILLATOR_GetValue ( void )
{

	//Configure Clock
	switch(CLKDIV) {
		case 0x3000:
			return CLOCK_16_MHZ;
		case 0x3040:
			return CLOCK_8_MHZ;
		case 0x3080:
			return CLOCK_4_MHZ;
		case 0x30C0:
			return CLOCK_2_MHZ;
		default:
			for(;;);                    // Safety
	}
	return 0;
} /* OSCILLATOR_GetValue */


/*------------------------------------------------------------------------------------------------*/
/* Function     : OSCILLATOR_GetRate                                         					  */
/*                                                                            					  */
/* Description  : get currently configured oscillator speed in hertz           					  */
/*                                                                            					  */
/* Arguments    : none                                                                            */
/*                                                                            					  */
/* Returns      : uint32_t rate value (hz)                                                        */
/*                                                                            					  */
/*------------------------------------------------------------------------------------------------*/

uint32_t OSCILLATOR_GetRate ( void )
{

	//Get Clock Value
	switch(CLKDIV) {
		case 0x3000:
			return 16000000;            // CLOCK_16_MHZ
		case 0x3040:
			return 8000000;             // CLOCK_8_MHZ
		case 0x3080:
			return 4000000;             // CLOCK_4_MHZ
		case 0x30C0:
			return 2000000;             // CLOCK_2_MHZ
		default:
			for(;;);                    // Safety
	}
	return 0;							// Warning silence
} /* OSCILLATOR_GetValue */


/*------------------------------------------------------------------------------------------------*/
/* Function     : OSCILLATOR_Inspect                                          					  */
/*                                                                            					  */
/* Description  : output the oscillator for inspection to 'x'                 					  */
/*                                                                            					  */
/* Arguments    : none                                                        					  */
/*                                                                            					  */
/* Returns      : no return                                                   					  */
/*                                                                            					  */
/*------------------------------------------------------------------------------------------------*/

void OSCILLATOR_Inspect ( void )
{
	//Setup
	LATA = 0x0000;
	TRISA = 0x7F9F;
	IOCPDA = 0x0000;
	IOCPUA = 0x0000;
	ODCA = 0x0000;
	ANSA = 0x000F;

	//Inspect
	for(;;);
} /* OSCILLATOR_Inspect */


/*------------------------------------------------------------------------------------------------*/
/* Function     :  Delay_Ms                                                   					  */
/*                                                                            					  */
/* Description  :  delay by specified time value                              					  */
/*                                                                            					  */
/* Arguments    :  uint32_t t_ms - time to delay (ms)                         					  */
/*                                                                            					  */
/* Returns      :  None                                                       					  */
/*------------------------------------------------------------------------------------------------*/

void Delay_Ms(uint32_t t_ms)
{
	//Vars
	uint32_t i, j;
	const float S = 0.02768750;							// t -> cts op
	const float FCY_f  = (float) OSCILLATOR_GetRate();
	const float t_ms_f = (float) t_ms;

	//Calc Loop Counts
	float loopCt_f = S*(t_ms_f)*(FCY_f);
	uint32_t loopCt = (uint32_t) (loopCt_f/1000);

	//Delay
	while(t_ms--) {
		for(i = 0; i<loopCt; i++) { j++; };     		//manual delay
	}

	return;
}


/*------------------------------------------------------------------------------------------------*/
/* Function     : COUNT_Value                                              		      			  */
/*                                                                            					  */
/* Description  : CT_RESET, CT_KEY2                					 							  */
/*                                                                            					  */
/* Arguments    : x												             					  */
/*                                                                            					  */
/* Returns      : none                                                 					          */
/*                                                                            					  */
/*------------------------------------------------------------------------------------------------*/

uint32_t COUNT_Value( uint32_t t_s )
{
	const uint32_t scale = 3200000L;

	return (scale*t_s)/OSCILLATOR_GetRate();
} /* COUNT_Value */


/*------------------------------------------------------------------------------------------------*/
/* Function     : COUNT_PowerDown                                             					  */
/*                                                                            					  */
/* Description  : #define CT_POWERDOWN	(A*T_POWERDOWN_S)/FCY                 					  */
/*                                                                            					  */
/* Note         : as #def causes warnings from casting                        					  */
/*                                                                            					  */
/* Arguments    : none                                                        					  */
/*                                                                            					  */
/* Returns      : uint32_t value                                              					  */
/*                                                                            					  */
/*------------------------------------------------------------------------------------------------*/

uint32_t COUNT_PowerDown( void )
{
	uint64_t a = 3200000L;
	uint64_t t = T_POWERDOWN_S;
	uint64_t f = OSCILLATOR_GetRate();

	uint64_t rslt = (a*t)/f;

	return rslt;
} /* COUNT_PowerDown */


/*------------------------------------------------------------------------------------------------*/
/* Function     : calcPR1Value                                            		      			  */
/*                                                                            					  */
/* Description  : TIMER_PR1_VAL(t)                					 							  */
/*                                                                            					  */
/* Arguments    : x												             					  */
/*                                                                            					  */
/* Returns      : none                                                 					          */
/*                                                                            					  */
/*------------------------------------------------------------------------------------------------*/

uint32_t calcPR1Value( uint32_t t_s )
{
	const uint64_t scale = 32000000000;

	return (scale/OSCILLATOR_GetRate())*t_s;
}


/*------------------------------------------------------------------------------------------------*/
/* Function     : tickCt                                                   		      			  */
/*                                                                            					  */
/* Description  : TICK_CT(t)                      					 							  */
/*                                                                            					  */
/* Arguments    : x												             					  */
/*                                                                            					  */
/* Returns      : none                                                 					          */
/*                                                                            					  */
/*------------------------------------------------------------------------------------------------*/

uint32_t tickCt( uint32_t t_ms  )
{
	return ((t_ms/TIMER_PERIOD_MS)/TICK_LOOP_CYCLE_CT);
}



/*------------------------------------------------------------------------------------------------*/
/* Function     : OSCCON_Init                                            		      			  */
/*                                                                            					  */
/* Description  : initialization of OSCCON control register	placed here							  */
/*                                                                            					  */
/* Location     : Address - 0100, Reset - xxx0													  */
/*                                                                            					  */
/* Reset Notes  : OSCCON Reset Value set by the type of Reset and FOSCSEL.FNOSCb2-0				  */
/*                                                                            					  */
/* Arguments    : uint16_t  val - write value					             					  */
/*                                                                            					  */
/* Returns      : none                                                 					          */
/*                                                                            					  */
/*------------------------------------------------------------------------------------------------*/

void OSCCON_Init( void )
{
	// FW initialization placed here.
}


/*------------------------------------------------------------------------------------------------*/
/* Function     : OSCCON_Write                                            		      			  */
/*                                                                            					  */
/* Description  : write value to OSCCON Control Register										  */
/*                                                                            					  */
/* Arguments    : uint16_t  val - write value					             					  */
/*                                                                            					  */
/* Returns      : none                                                 					          */
/*                                                                            					  */
/* Assume       : value is valid for write & use				             					  */
/*                                                                            					  */
/*------------------------------------------------------------------------------------------------*/

void OSCCON_Write( uint16_t  val )
{
	//Gen values
	uint8_t val_low  = (uint8_t)(val);
	uint8_t val_high = (uint8_t)(val>>8);

	//Write values
    __builtin_write_OSCCONL(val_low);
    __builtin_write_OSCCONH(val_high);

	return;
}

/*------------------------------------------------------------------------------------------------*/
/* Function     : OSCCON_Write                                            		      			  */
/*                                                                            					  */
/* Description  : write value to OSCCON Control Register										  */
/*                                                                            					  */
/* Arguments    : uint16_t  val - write value					             					  */
/*                                                                            					  */
/* Returns      : none                                                 					          */
/*                                                                            					  */
/* Assume       : value is valid for write & use				             					  */
/*                                                                            					  */
/*------------------------------------------------------------------------------------------------*/

void OSCCON_And( uint16_t  val )
{
    //Calc reg value
    val &= OSCCON;
    
	//Gen values
	uint8_t val_low  = (uint8_t)(val);
	uint8_t val_high = (uint8_t)(val>>8);

	//Write values
    __builtin_write_OSCCONL(val_low);
    __builtin_write_OSCCONH(val_high);

	return;
}

/*------------------------------------------------------------------------------------------------*/
/* Function     : OSCCON_Write                                            		      			  */
/*                                                                            					  */
/* Description  : write value to OSCCON Control Register										  */
/*                                                                            					  */
/* Arguments    : uint16_t  val - write value					             					  */
/*                                                                            					  */
/* Returns      : none                                                 					          */
/*                                                                            					  */
/* Assume       : value is valid for write & use				             					  */
/*                                                                            					  */
/*------------------------------------------------------------------------------------------------*/

void OSCCON_Or( uint16_t  val )
{
    //Calc reg value
    val |= OSCCON;
    
	//Gen values
	uint8_t val_low  = (uint8_t)(val);
	uint8_t val_high = (uint8_t)(val>>8);

	//Write values
    __builtin_write_OSCCONL(val_low);
    __builtin_write_OSCCONH(val_high);

	return;
}


/*------------------------------------------------------------------------------------------------*/
/* Function     : OSCCON_Write                                            		      			  */
/*                                                                            					  */
/* Description  : write value to OSCCON Control Register										  */
/*                                                                            					  */
/* Arguments    : uint16_t  val - write value					             					  */
/*                                                                            					  */
/* Returns      : none                                                 					          */
/*                                                                            					  */
/* Assume       : value is valid for write & use				             					  */
/*                                                                            					  */
/*------------------------------------------------------------------------------------------------*/

void OSCCON_Xor( uint16_t  val )
{
    //Calc reg value
    val ^= OSCCON;
    
	//Gen values
	uint8_t val_low  = (uint8_t)(val);
	uint8_t val_high = (uint8_t)(val>>8);

	//Write values
    __builtin_write_OSCCONL(val_low);
    __builtin_write_OSCCONH(val_high);

	return;
}


/**************************************************************************************************/

