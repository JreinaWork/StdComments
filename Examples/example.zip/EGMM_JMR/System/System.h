/**************************************************************************************************/
/* Title        :  PIC24F configurations                                                 	 	  */
/*------------------------------------------------------------------------------------------------*/
/* File         :  System.h                                                                       */
/* Author       :  Justin Reina                                                                   */
/* Company      :  Intellectual Ventures Laboratory                                               */
/* Project      :  MAISE EGMM Proof of Concept Device (De-risk testing)                           */
/* Created      :  22 Mar 2018                                                                    */
/* Compiler     :  Microchip MPLAB XC16, Ver. 1.33                                                */
/* Target       :  PIC24FJ256GA702-I/ML                                                           */
/*------------------------------------------------------------------------------------------------*/
/* Description  :  x                                                                              */
/*------------------------------------------------------------------------------------------------*/
/* Copyright    :  (c) 2018 Intellectual Ventures  All rights reserved                            */
/**************************************************************************************************/
#ifndef SYSTEM_H_
#define SYSTEM_H_

/**************************************************************************************************/
/*                                         INCLUDES                                               */
/**************************************************************************************************/

// Project
#include "Globals.h"

/**************************************************************************************************/
/*                                      GLOBAL VARIABLES                                          */
/**************************************************************************************************/

extern bool DoClear;
extern bool SecondFlag;
extern bool Key1Pressed;
extern bool Key2Pressed;
extern bool PowerOffNow;
extern bool Running;

/**************************************************************************************************/
/*                                      GLOBAL FUNCTIONS                                          */
/**************************************************************************************************/

extern void SYSTEM_Initialize( void );
extern void SYSTEM_PowerDown( void );
extern void KEY1_Reset( void );
extern void RUN_Start( void );
extern void KEYS_Init( void );

#endif  /* SYSTEM_H_ */

