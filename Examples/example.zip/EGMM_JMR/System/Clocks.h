/**************************************************************************************************/
/* Title        :  EGMM clock & timing                                                   	 	  */
/*------------------------------------------------------------------------------------------------*/
/* File         :  Clocks.h                                                                       */
/* Author       :  Justin Reina                                                                   */
/* Company      :  Intellectual Ventures Laboratory                                               */
/* Project      :  MAISE EGMM Proof of Concept Device (De-risk testing)                           */
/* Created      :  06 Apr 2018                                                                    */
/* Compiler     :  Microchip MPLAB XC16, Ver. 1.33                                                */
/* Target       :  PIC24FJ256GA702-I/ML                                                           */
/*------------------------------------------------------------------------------------------------*/
/* Description  :  x                                                                              */
/*------------------------------------------------------------------------------------------------*/
/* Copyright    :  (c) 2018 Intellectual Ventures  All rights reserved                            */
/**************************************************************************************************/
#ifndef CLOCKS_H_
#define CLOCKS_H_

/**************************************************************************************************/
/*                                         INCLUDES                                               */
/**************************************************************************************************/

// Library
#include "Globals.h"

/**************************************************************************************************/
/*                                          TYPEDEFS                                              */
/**************************************************************************************************/

typedef enum clockCfg {
	CLOCK_2_MHZ,
	CLOCK_4_MHZ,
	CLOCK_8_MHZ,
	CLOCK_16_MHZ,
} ClockCfg;

/**************************************************************************************************/
/*                                        DEFINITIONS                                             */
/**************************************************************************************************/

#define FOSC 				(32000000L)                 // Frequency - PLL Output
#define FCY_EGMM_TEMP       (FOSC/2)                    // Frequency - Instruction Cycle
														// @note 'FCY' not defined for delay fcns
//Counts
#define T_POWERDOWN_S		(2000)						// unsure of equation used
#define T_RESET_S 			(30)
#define T_KEY2_S			(30)
#define CT_POWERDOWN    	(COUNT_PowerDown())

//Timing values
#define TIMER_PERIOD_MS     (10)                   		// [ms] timer period
#define TICK_LOOP_CYCLE_CT	(8)
#define TS_MS               (1000)                   	// [ms] sample interval
#define TICK_CT_DAQ			((32000000/OSCILLATOR_GetRate())*50000) // e.g. "100000" for 16MHz
#define TICKS_INIT_VAL 		(200)						// init val for Ticks (2sec)
#define DELAY_CT_5_MS  		(2895)                      // delay count for 5ms in BLE transmit

/**************************************************************************************************/
/*                                  FUNCTION DEFINITIONS                                          */
/**************************************************************************************************/

ClockCfg OSCILLATOR_GetValue ( void );

/**************************************************************************************************/
/*                                      GLOBAL FUNCTIONS                                          */
/**************************************************************************************************/

extern void CLOCKS_Init( void );

extern void OSCILLATOR_Initialize( void );
extern void OSCILLATOR_SetValue( ClockCfg cfg );
extern uint32_t OSCILLATOR_GetRate ( void );
extern void OSCILLATOR_Inspect( void );

extern void Delay_Ms(uint32_t t_ms);

extern uint32_t COUNT_Value( uint32_t t_s );
extern uint32_t COUNT_PowerDown( void );

extern uint32_t calcPR1Value( uint32_t t_s );
extern uint32_t tickCt( uint32_t t_ms  );

extern void OSCCON_Init( void );
extern void OSCCON_Write( uint16_t  val );

/**************************************************************************************************/
/*                                      GLOBAL VARIABLES                                          */
/**************************************************************************************************/

extern int Ticks;
extern int ElapsedTime;
extern int DaqTime;

#endif  /* CLOCKS_H_ */

